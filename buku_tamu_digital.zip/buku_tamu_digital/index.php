<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Buku Tamu Digital</title>

    <!-- Bootstrap -->

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <!-- Bootstrap Icons -->

    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">

    <!-- Google Fonts -->

    <link rel="preconnect"
          href="https://fonts.googleapis.com">

    <link rel="preconnect"
          href="https://fonts.gstatic.com"
          crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
          rel="stylesheet">

    <!-- CSS -->

    <link rel="stylesheet"
          href="assets/css/style.css">

</head>

<body>

    <div class="background-overlay"></div>

    <!-- ==========================
            Navbar
    =========================== -->

    <nav class="navbar navbar-expand-lg navbar-light shadow-sm">

        <div class="container">

            <a class="navbar-brand fw-bold"
               href="index.php">

                <i class="bi bi-journal-bookmark-fill me-2"></i>

                Buku Tamu Digital

            </a>

        </div>

    </nav>

    <!-- ==========================
            Hero
    =========================== -->

    <section class="hero-section">

        <div class="container">

            <div class="row justify-content-center">

                <div class="col-lg-8">

                    <div class="card landing-card">

                        <div class="card-body text-center">

                            <div class="hero-icon">

                                <i class="bi bi-building-fill-check"></i>

                            </div>

                            <h1 class="hero-title">

                                Selamat Datang

                            </h1>

                            <h5 class="mb-4 text-secondary">

                                Sistem Buku Tamu Digital

                            </h5>

                            <p class="hero-subtitle">

                                Website ini digunakan untuk mencatat data
                                kunjungan tamu secara digital sehingga
                                proses administrasi menjadi lebih cepat,
                                rapi, dan mudah dikelola oleh pihak sekolah.

                            </p>
                            <div class="action-buttons mt-5">

                                <a href="buku_tamu.php"
                                   class="btn btn-primary btn-lg me-3">

                                    <i class="bi bi-person-plus-fill me-2"></i>

                                    Isi Buku Tamu

                                </a>

                                <a href="login.php"
                                   class="btn btn-outline-primary btn-lg">

                                    <i class="bi bi-box-arrow-in-right me-2"></i>

                                    Login Admin

                                </a>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

    <script src="assets/js/script.js"></script>

</body>

</html>