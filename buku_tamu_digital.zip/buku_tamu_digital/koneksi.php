<?php

/* ===========================
   Konfigurasi Database
=========================== */

$db_host = "localhost";
$db_username = "root";
$db_password = "";
$db_name = "db_buku_tamu";


/* ===========================
   Membuat Koneksi
=========================== */

$koneksi = mysqli_connect($db_host, $db_username, $db_password, $db_name);


/* ===========================
   Cek Koneksi
=========================== */

if (!$koneksi) {
    die("Koneksi database gagal : " . mysqli_connect_error());
}
?>