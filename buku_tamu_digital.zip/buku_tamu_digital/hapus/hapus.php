<?php
// Arahkan ke file koneksi (mundur satu tingkat ke folder utama)
require '../koneksi.php';

// Cek apakah parameter ID tersedia di URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Gunakan prepared statement untuk keamanan dari SQL Injection
    $stmt = mysqli_prepare($koneksi, "DELETE FROM tamu WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);

    if (mysqli_stmt_execute($stmt)) {
        // Berhasil dihapus, kembalikan ke halaman utama dengan status
        header('Location: ../index.php?status=deleted');
        exit;
    } else {
        echo "Gagal menghapus data: " . mysqli_error($koneksi);
    }

    mysqli_stmt_close($stmt);
} else {
    // Jika tidak ada ID, kembalikan langsung ke index
    header('Location: ../index.php');
    exit;
}
?>