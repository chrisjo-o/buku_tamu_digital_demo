<?php
include "koneksi.php";
?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Buku Tamu Digital</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">

    <!-- Google Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">

    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

    <div class="background-overlay"></div>

    <!-- Navbar -->

    <nav class="navbar navbar-expand-lg navbar-light shadow-sm">

        <div class="container">

            <a class="navbar-brand fw-bold" href="index.php">

                <i class="bi bi-journal-bookmark-fill me-2"></i>

                Buku Tamu Digital

            </a>

        </div>

    </nav>

    <!-- Hero -->

    <section class="hero-section">

        <div class="container">

            <div class="row justify-content-center">

                <div class="col-lg-8 text-center">

                    <h1 class="hero-title">

                        Selamat Datang

                    </h1>

                    <p class="hero-subtitle">

                        Silakan mengisi buku tamu sebagai data kunjungan.
                        Pastikan informasi yang diberikan benar agar dapat
                        digunakan sebagai arsip administrasi sekolah.

                    </p>

                </div>

            </div>

        </div>

    </section>

    <!-- Form -->

    <section class="pb-5">

        <div class="container">

            <div class="row justify-content-center">

                <div class="col-lg-8">

                    <div class="card form-card">

                        <div class="card-header">

                            <h4 class="mb-0">

                                <i class="bi bi-pencil-square me-2"></i>

                                Form Buku Tamu

                            </h4>

                        </div>

                        <div class="card-body">

                            <form action="tambah/tambah.php" method="POST">

                                <div class="mb-3">

                                    <label class="form-label">

                                        <i class="bi bi-person-fill me-2"></i>

                                        Nama Tamu

                                    </label>

                                    <input
                                        type="text"
                                        class="form-control"
                                        name="nama_tamu"
                                        placeholder="Masukkan nama tamu"
                                        autocomplete="name"
                                        required>

                                </div>

                                <div class="mb-3">

                                    <label class="form-label">

                                        <i class="bi bi-building me-2"></i>

                                        Instansi

                                    </label>

                                    <input
                                        type="text"
                                        class="form-control"
                                        name="instansi"
                                        placeholder="Masukkan instansi"
                                        required>

                                </div>

                                <div class="mb-3">

                                    <label class="form-label">

                                        <i class="bi bi-bullseye me-2"></i>

                                        Tujuan

                                    </label>

                                    <input
                                        type="text"
                                        class="form-control"
                                        name="tujuan"
                                        placeholder="Contoh : Bertemu Kepala Sekolah"
                                        required>

                                </div>
                                <div class="mb-3">

                                    <label class="form-label">

                                        <i class="bi bi-calendar-event-fill me-2"></i>

                                        Waktu Kunjungan

                                    </label>

                                    <input
                                        type="datetime-local"
                                        class="form-control"
                                        name="waktu_kunjungan"
                                        value="<?php echo date('Y-m-d\TH:i'); ?>"
                                        required>

                                </div>

                                <div class="mb-4">

                                    <label class="form-label">

                                        <i class="bi bi-chat-left-text-fill me-2"></i>

                                        Keterangan

                                    </label>

                                    <textarea
                                        class="form-control"
                                        name="keterangan"
                                        rows="4"
                                        placeholder="Tuliskan keterangan apabila diperlukan..."></textarea>

                                </div>

                                <div class="row g-3">

                                    <div class="col-md-6 d-grid">

                                        <button
                                            type="submit"
                                            name="simpan"
                                            class="btn btn-primary">

                                            <i class="bi bi-check-circle-fill me-2"></i>

                                            Simpan

                                        </button>

                                    </div>

                                    <div class="col-md-6 d-grid">

                                        <button
                                            type="reset"
                                            class="btn btn-outline-secondary">

                                            <i class="bi bi-arrow-clockwise me-2"></i>

                                            Reset

                                        </button>

                                    </div>

                                </div>

                            </form>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

    <script src="assets/js/script.js"></script>

</body>

</html>