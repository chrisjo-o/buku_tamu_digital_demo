<?php

include "../koneksi.php";

if (isset($_POST['simpan'])) {

    $nama_tamu = trim($_POST['nama_tamu']);
    $instansi = trim($_POST['instansi']);
    $tujuan = trim($_POST['tujuan']);
    $waktu_kunjungan = $_POST['waktu_kunjungan'];
    $keterangan = trim($_POST['keterangan']);

    $stmt = $conn->prepare("INSERT INTO tamu (nama_tamu, instansi, tujuan, waktu_kunjungan, keterangan) VALUES (?, ?, ?, ?, ?)");

    $stmt->bind_param(
        "sssss",
        $nama_tamu,
        $instansi,
        $tujuan,
        $waktu_kunjungan,
        $keterangan
    );

    if ($stmt->execute()) {

        echo "<script>
                alert('Data berhasil disimpan.');
                window.location='../buku_tamu.php';
              </script>";

    } else {

        echo "<script>
                alert('Data gagal disimpan.');
                window.location='../buku_tamu.php';
              </script>";

    }

    $stmt->close();
}

$conn->close();

?>